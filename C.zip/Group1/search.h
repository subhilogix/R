#ifndef SEARCH_H
#define SEARCH_H
#define MAX 100
extern int graph[MAX][MAX];
extern int n;
extern int depth[MAX];
extern int OPEN[MAX];
extern int opensize;
extern int CLOSED[MAX];
extern int closedsize;

void addOpen(int node);
int removeOpen();
int removeOpenfromfirst();
void addClosed(int node);

int isInOpen(int node);
int isInClosed(int node);

int goalTest(int node,int goal);
void moveGen(int node);

#endif
