#include<stdio.h>
#include "declarations.h"

int main(){
    int graph[N][N];

    int start=0;
    int goal=7;

    int openSize;
    int closedSize;

    int successors[N];
    int count;
    int has_successors;

    NodePair open[MAX_OPEN];
    NodePair closed[MAX_OPEN];

    NodePair n;
    NodePair newNode;

    initializeGraph(graph);
    openSize=0;
    closedSize=0;

    open[openSize].state=start;
    open[openSize].parent=-1;
    open[openSize].depth=0;
    openSize++;

    printf("DFS TRAVERSAL..\n");
    while(openSize>0){
        n=removeFront(open,&openSize);
        printf("Expanding:%d\n",n.state);
        if(GoalTest(n.state,goal)){
            addClosed(closed,&closedSize,n);
            printf("GOAL FOUND\n");
            printf("Path to the goal :\n");
            printPath(closed,closedSize,start,goal);
            return 0;
        }
        addClosed(closed,&closedSize,n);
        MoveGen(graph,n.state,successors,&count,&has_successors);
        if(has_successors==0){
            printf("Backtracking from %d to %d\n",n.state,n.parent);
            continue;
        }
        for(int i=count-1;i>=0;i--){
            if(isInClosed(closed,closedSize,successors[i])){
                continue;
            }
            if(isInOpen(open,openSize,successors[i])){
                continue;
            }
            newNode.state=successors[i];
            newNode.parent=n.state;
            newNode.depth=n.depth+1;
            addFront(open,&openSize,newNode);
        }

    }
    return 0;



}