#include <stdio.h>

#define MAX_NODES 20
#define MAX_BEAM 10

int graph[MAX_NODES][MAX_NODES];
int value[MAX_NODES];
int beam[MAX_BEAM];
int beamSize;

/* Parent of each node */
int parent[MAX_NODES];

/* ---------------- GOAL TEST ---------------- */
int GoalTest(int current, int goal)
{
    return current == goal;
}

/* ---------------- MOVE GENERATOR ---------------- */
int MoveGen(int current, int successors[])
{
    int count = 0;
    for(int i = 0; i < MAX_NODES; i++)
    {
        if(graph[current][i] == 1)
        {
            successors[count] = i;
            count++;
        }
    }
    return count;
}

/* ---------------- RECONSTRUCT PATH ---------------- */
void reconstructPath(int start, int goal)
{
    int path[MAX_NODES];
    int pathSize = 0;
    int current = goal;
    while(current != -1)
    {
        path[pathSize] = current;
        pathSize++;
        if(current == start)
            break;
        current = parent[current];
    }
    printf("Path: ");
    for(int i = pathSize - 1; i >= 0; i--)
    {
        printf("%c", 'A' + path[i]);
        if(i != 0)
            printf(" -> ");
    }
    printf("\n");
}

/* ---------------- BEAM SEARCH ---------------- */
void beamSearch(int start, int goal, int width)
{
    beam[0] = start;
    beamSize = 1;
    /* Initially start has no parent */
    parent[start] = -1;
    while(beamSize > 0)
    {
        printf("\nCurrent Beam: ");
        for(int i = 0; i < beamSize; i++)
        {
            printf("%c(%d) ",'A' + beam[i], value[beam[i]]);
        }
        /* Check whether goal is in current beam */
        for(int i = 0; i < beamSize; i++)
        {
            if(GoalTest(beam[i], goal))
            {
                printf("\nGoal found: %c\n",'A' + goal);
                reconstructPath(start, goal);
                return;
            }
        }
        /*
            Generate candidates
            from every node in current beam
        */
        int candidates[MAX_NODES];
        int candidateParent[MAX_NODES];
        int candidateCount = 0;
        for(int i = 0; i < beamSize; i++)
        {
            int current = beam[i];
            int successors[MAX_NODES];
            int count =MoveGen(current,successors);
            for(int j = 0; j < count; j++)
            {
                int child = successors[j];
                candidates[candidateCount] = child;
                /*
                    Remember which beam node
                    generated this candidate
                */
                candidateParent[candidateCount] = current;
                candidateCount++;
            }
        }

        if(candidateCount == 0)
        {
            printf("\nNo more candidates.\n");
            return;
        }
        /*
            Sort candidates in decreasing
            order of value
        */
        for(int i = 0;i < candidateCount - 1;i++)
        {
            for(int j = i + 1;j < candidateCount;j++)
            {
                if(value[candidates[j]] > value[candidates[i]])
                {
                    int temp;

                    temp = candidates[i];
                    candidates[i] = candidates[j];
                    candidates[j] = temp;

                    /*
                        Parent must also move
                        along with the candidate
                    */

                    temp = candidateParent[i];

                    candidateParent[i] =candidateParent[j];
                    candidateParent[j] = temp;
                }
            }
        }

        /*
            Keep only the best 'width'
            candidates
        */
        beamSize = 0;
        for(int i = 0;i < candidateCount && i < width;i++)
        {
            beam[beamSize] = candidates[i];
            /*
                Store parent for path reconstruction
            */
            parent[candidates[i]] = candidateParent[i];
            beamSize++;
        }
    }
}

/* ---------------- MAIN ---------------- */

int main()
{
    /* Values */

    value[0] = 0;   // A
    value[1] = 6;   // B
    value[2] = 9;   // C
    value[3] = 5;   // D
    value[4] = 7;   // E
    value[5] = 4;   // F
    value[6] = 8;   // G
    value[7] = 10;  // H
    value[8] = 3;   // I
    value[9] = 6;   // J

    /* A -> B, C, D */

    graph[0][1] = 1;
    graph[0][2] = 1;
    graph[0][3] = 1;

    /* B -> E, F */

    graph[1][4] = 1;
    graph[1][5] = 1;

    /* C -> G, H */

    graph[2][6] = 1;
    graph[2][7] = 1;

    /* D -> I, J */

    graph[3][8] = 1;
    graph[3][9] = 1;

    /*
        Start = A
        Goal = H
        Beam width = 4
    */
    beamSearch(0, 7, 4);
    return 0;
}