#ifndef COMMON_H
#define COMMON_H

#define N 8
#define MAX_OPEN 100

/*
    Node numbering:    
    0 -> S
    1 -> A
    2 -> B
    3 -> C
    4 -> D
    5 -> E
    6 -> F
    7 -> G
*/

typedef struct
{
    int state;
    int parent;
    int depth;
} NodePair;


/* Graph functions */
void initializeGraph(int graph[N][N]);

int MoveGen(int graph[N][N],int state,int successors[],int *count,int *has_successors);
int GoalTest(int state, int goal);
void initializeOpen(NodePair open[], int *size);
void addFront(NodePair open[],int *size,NodePair node);
void addBack(NodePair open[],int *size,NodePair node);
NodePair removeFront(NodePair open[],int *size);
int isInOpen(NodePair open[],int size,int state);
int isInClosed(NodePair closed[],int size,int state);
void addClosed(NodePair closed[],int *size,NodePair node);
void printNode(int state);
void printOpen(NodePair open[], int size);
void printPath(NodePair closed[],int closedSize,int start,int goal);

#endif