#include <stdio.h>
#include "declarations.h"

int main()
{
    int graph[N][N];

    NodePair open[MAX_OPEN];
    NodePair closed[MAX_OPEN];

    int openSize;
    int closedSize;

    int start = 0;
    int goal = 7;

    int successors[N];
    int count;
    int has_successors;

    NodePair n;
    NodePair newNode;

    // Initialize graph
    initializeGraph(graph);

    // // Initialize OPEN
    // initializeOpen(open, &openSize);
    openSize=0;
    // Initialize CLOSED
    closedSize = 0;

    // Add start node to OPEN
    open[openSize].state = start;
    open[openSize].parent = -1;
    open[openSize].depth = 0;
    openSize++;

    printf("DFS Traversal:\n");

    while (openSize > 0)
    {
        // Remove first node from OPEN
        n = removeFront(open, &openSize);

        printf("Expanding: ");
        printNode(n.state);
        printf("\n");

        // Goal test
        if (GoalTest(n.state, goal))
        {
            addClosed(closed, &closedSize, n);

            printf("\nGoal Found!\n");
            printPath(closed, closedSize, start, goal);

            return 0;
        }

        // Add current node to CLOSED
        addClosed(closed, &closedSize, n);

        // Generate successors
        MoveGen(graph, n.state, successors, &count, &has_successors);

        // If no successors
        if (has_successors == 0)
    {
        printf("Backtracking: ");
        printNode(n.state);
        printf(" -> ");
        printNode(n.parent);
        printf("\n");

        continue;
    }

        // DFS: add successors to FRONT
        for (int i = count - 1; i >= 0; i--)
        {
            int s = successors[i];

            // Skip if already explored
            if (isInClosed(closed, closedSize, s))
                continue;

            // Skip if already waiting in OPEN
            if (isInOpen(open, openSize, s))
                continue;

            newNode.state = s;
            newNode.parent = n.state;
            newNode.depth = n.depth + 1;

            addFront(open, &openSize, newNode);
        }

        // Optional: display OPEN
        printOpen(open, openSize);
    }

    printf("\nGoal not found.\n");

    return 0;
}