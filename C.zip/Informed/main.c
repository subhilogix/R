#include <stdio.h>
#include "declarations.h"


void initializeGraph(int graph[N][N], int cost[N][N])
{
    int i, j;

    for(i = 0; i < N; i++)
    {
        for(j = 0; j < N; j++)
        {
            graph[i][j] = 0;
            cost[i][j] = 0;
        }
    }

    // A-B = 6
    addEdge(graph, cost, 1, 2, 6);

    // A-F = 3
    addEdge(graph, cost, 1, 6, 3);

    // B-C = 3
    addEdge(graph, cost, 2, 3, 3);

    // B-D = 2
    addEdge(graph, cost, 2, 4, 2);

    // C-D = 1
    addEdge(graph, cost, 3, 4, 1);

    // C-E = 5
    addEdge(graph, cost, 3, 5, 5);

    // D-E = 8
    addEdge(graph, cost, 4, 5, 8);

    // E-I = 5
    addEdge(graph, cost, 5, 9, 5);

    // E-J = 5
    addEdge(graph, cost, 5, 10, 5);

    // J-I = 3
    addEdge(graph, cost, 10, 9, 3);

    // I-G = 3
    addEdge(graph, cost, 9, 7, 3);

    // I-H = 2
    addEdge(graph, cost, 9, 8, 2);

    // G-F = 1
    addEdge(graph, cost, 7, 6, 1);

    // H-F = 7
    addEdge(graph, cost, 8, 6, 7);
}


void addEdge(int graph[N][N], int cost[N][N],
             int u, int v, int edgeCost)
{
    graph[u][v] = 1;
    graph[v][u] = 1;

    cost[u][v] = edgeCost;
    cost[v][u] = edgeCost;
}


int GoalTest(int state, int goal)
{
    return state == goal;
}


/*
    Insert node into OPEN.
    OPEN is kept unsorted.
*/
void addOpen(Node open[], int *openSize, Node node)
{
    if(*openSize >= MAX_OPEN)
        return;

    open[*openSize] = node;
    (*openSize)++;
}


/*
    Find and remove node with
    minimum path cost.
*/
Node removeMin(Node open[], int *openSize)
{
    int i;
    int minIndex = 0;
    Node selected;
    for(i = 1; i < *openSize; i++)
    {
        if(open[i].cost < open[minIndex].cost)
        {
            minIndex = i;
        }
    }

    selected = open[minIndex];

    // Shift remaining elements
    for(i = minIndex; i < *openSize - 1; i++)
    {
        open[i] = open[i + 1];
    }

    (*openSize)--;

    return selected;
}


int isInOpen(Node open[], int openSize, int state)
{
    int i;

    for(i = 0; i < openSize; i++)
    {
        if(open[i].state == state)
            return 1;
    }

    return 0;
}


int isInClosed(Node closed[], int closedSize, int state)
{
    int i;
    for(i = 0; i < closedSize; i++)
    {
        if(closed[i].state == state)
            return 1;
    }
    return 0;
}


void addClosed(Node closed[], int *closedSize, Node node)
{
    if(*closedSize >= MAX_OPEN)
        return;

    closed[*closedSize] = node;
    (*closedSize)++;
}


void printNode(int state)
{
    char nodes[N] =
    {
        ' ',
        'A',
        'B',
        'C',
        'D',
        'E',
        'F',
        'G',
        'H',
        'I',
        'J'
    };

    printf("%c", nodes[state]);
}


void printPath(Node closed[], int closedSize,
               int start, int goal)
{
    int path[N];
    int pathSize = 0;

    int current = goal;
    int found;

    int i;
    int j;

    while(current != start)
    {
        path[pathSize] = current;
        pathSize++;

        found = 0;

        for(i = 0; i < closedSize; i++)
        {
            if(closed[i].state == current)
            {
                current = closed[i].parent;
                found = 1;
                break;
            }
        }

        if(!found)
        {
            printf("Path reconstruction failed.\n");
            return;
        }
    }

    path[pathSize] = start;
    pathSize++;

    printf("Path: ");

    for(j = pathSize - 1; j >= 0; j--)
    {
        printNode(path[j]);

        if(j != 0)
            printf(" -> ");
    }

    printf("\n");
}