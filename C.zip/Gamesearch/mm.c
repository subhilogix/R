#include<stdio.h>
#include<limits.h>
#define MAX_NODES 50
#define MAX_CHILDREN 10
// Node strucutre

typedef struct{
    int children[MAX_CHILDREN];
    int childcount;
    int value;
    int terminal;
}Node;
typedef struct{
    int bestmove;
    int bestvalue;
}Return;
Node tree[MAX_NODES];
Return mm(int child,int m){
    if(tree[child].terminal==1){
        Return r;
        r.bestvalue=tree[child].value;
        r.bestmove=-1;
        return r;
    }

    if(m==1){
        int bv=INT_MIN;
        int bm=-1;
        for(int i=0;i<tree[child].childcount;i++){
            Return r=mm(tree[child].children[i],0);
            if(r.bestvalue>bv){
                bv=r.bestvalue;
                bm=tree[child].children[i];
            }
            
        }
        Return ans;
        ans.bestmove=bm;
        ans.bestvalue=bv;
        return ans;

    }

    if(m==0){
        int bv=INT_MAX;
        int bm=-1;
        for(int i=0;i<tree[child].childcount;i++){
            Return r=mm(tree[child].children[i],1);
            if(r.bestvalue<bv){
                bm=tree[child].children[i];
                bv=r.bestvalue;
            }

        }
        Return ans;
        ans.bestmove=bm;
        ans.bestvalue=bv;
        return ans;
    }
}

int main(){
    tree[1].childcount=2;
    tree[1].children[0]=2;
    tree[1].children[1]=3;

    tree[2].childcount=2;
    tree[2].children[0]=4;
    tree[2].children[1]=5;

    tree[3].childcount=2;
    tree[3].children[0]=6;
    tree[3].children[1]=7;

    tree[4].childcount=2;
    tree[4].children[0]=8;
    tree[4].children[1]=9;
    
    tree[8].terminal=1;
    tree[8].value=4;
    tree[9].terminal=1;
    tree[9].value=7;

    tree[5].childcount=2;
    tree[5].children[0]=10;
    tree[5].children[1]=11;

    tree[10].terminal=1;
    tree[10].value=2;
    tree[11].terminal=1;
    tree[11].value=9;

    tree[6].childcount=2;
    tree[6].children[0]=12;
    tree[6].children[1]=13;
    
    tree[12].terminal=1;
    tree[12].value=6;
    tree[13].terminal=1;
    tree[13].value=1;

    tree[7].childcount=2;
    tree[7].children[0]=14;
    tree[7].children[1]=15;
    tree[14].terminal=1;
    tree[15].terminal=1;
    tree[14].value=8;
    tree[15].value=5;
    Return r=mm(1,1);
    printf("BEST VALUE :%d\n",r.bestvalue);
    printf("BEST MOVE :%d\n",r.bestmove);
    return 0;
}