#include <stdio.h>
#include "declarations.h"

int heuristic[N] = {0, 10, 8, 5, 7, 3, 6, 5, 3, 1, 0};

int main()
{
    int graph[N][N];
    int cost[N][N];

    Node open[MAX_OPEN];
    Node closed[MAX_OPEN];

    int opensize = 0;
    int closedsize = 0;

    int start = 1;
    int goal = 10;

    int i;
    int min_index;

    Node n;
    Node newnode;

    initializeGraph(graph, cost);

    /* Add start node to OPEN */
    open[opensize].state = start;
    open[opensize].parent = -1;
    open[opensize].cost = 0;
    opensize++;

    printf("GREEDY BEST-FIRST SEARCH\n\n");

    while(opensize > 0)
    {
        /*
            Find the node having
            minimum heuristic h(n)
        */

        min_index = 0;

        for(i = 1; i < opensize; i++)
        {
            if(heuristic[open[i].state] <
               heuristic[open[min_index].state])
            {
                min_index = i;
            }
        }

        /* Remove selected node from OPEN */
        n = open[min_index];

        for(i = min_index; i < opensize - 1; i++)
        {
            open[i] = open[i + 1];
        }

        opensize--;

        printf("Expanding ");
        printNode(n.state);
        printf("  h = %d\n", heuristic[n.state]);

        /* Goal test */
        if(GoalTest(n.state, goal))
        {
            addClosed(closed, &closedsize, n);

            printf("\nGoal found!\n");
            printPath(closed, closedsize, start, goal);

            printf("Path Cost = %d\n", n.cost);

            return 0;
        }

        /* Move node to CLOSED */
        addClosed(closed, &closedsize, n);

        /*
            Generate all neighbours
        */
        for(i = 0; i < N; i++)
        {
            if(graph[n.state][i] == 1)
            {
                /* Skip if already explored */
                if(isInClosed(closed, closedsize, i))
                {
                    continue;
                }

                /* Skip if already in OPEN */
                if(isInOpen(open, opensize, i))
                {
                    continue;
                }

                newnode.state = i;
                newnode.parent = n.state;

                /*
                    Greedy uses h(n) for selection.
                    cost is only stored for path cost.
                */
                newnode.cost =
                    n.cost + cost[n.state][i];

                addOpen(open, &opensize, newnode);
            }
        }
    }

    printf("\nGoal not found.\n");

    return 0;
}