#include <stdio.h>
#include "declarations.h"

int heuristic[N] = {0, 10, 8, 5, 7, 3, 6, 5, 3, 1, 0};

int main()
{
    int graph[N][N];
    int cost[N][N];

    Node open[MAX_OPEN];
    Node closed[MAX_OPEN];

    int opensize = 0;
    int closedsize = 0;

    int start = 1;
    int goal = 10;

    int i;
    int j;
    int min_index;

    Node n;
    Node newnode;

    initializeGraph(graph, cost);

    /* Add start node to OPEN */
    open[opensize].state = start;
    open[opensize].parent = -1;
    open[opensize].cost = 0;
    opensize++;

    printf("A* SEARCH ALGORITHM\n\n");

    while(opensize > 0)
    {
        /*
            Find node with minimum f(n)

            f(n) = g(n) + h(n)

            g(n) = path cost
            h(n) = heuristic
        */

        min_index = 0;

        for(i = 1; i < opensize; i++)
        {
            if(open[i].cost + heuristic[open[i].state] <
               open[min_index].cost +
               heuristic[open[min_index].state])
            {
                min_index = i;
            }
        }

        /* Remove selected node from OPEN */
        n = open[min_index];

        for(i = min_index; i < opensize - 1; i++)
        {
            open[i] = open[i + 1];
        }

        opensize--;

        printf("Expanding ");
        printNode(n.state);
        printf("  g = %d", n.cost);
        printf("  h = %d", heuristic[n.state]);
        printf("  f = %d\n",
               n.cost + heuristic[n.state]);

        /* Goal test */
        if(GoalTest(n.state, goal))
        {
            addClosed(closed, &closedsize, n);

            printf("\nGoal found!\n");

            printPath(closed,
                      closedsize,
                      start,
                      goal);

            printf("Path Cost = %d\n", n.cost);

            return 0;
        }

        /* Move current node to CLOSED */
        addClosed(closed, &closedsize, n);

        /* Generate neighbours */
        for(i = 0; i < N; i++)
        {
            if(graph[n.state][i] == 1)
            {
                int newcost;
                int index = -1;

                /* Skip if already in CLOSED */
                if(isInClosed(closed, closedsize, i))
                {
                    continue;
                }

                /* Calculate new g(n) */
                newcost =
                    n.cost + cost[n.state][i];

                /*
                    Check whether node is
                    already present in OPEN
                */
                for(j = 0; j < opensize; j++)
                {
                    if(open[j].state == i)
                    {
                        index = j;
                        break;
                    }
                }

                if(index != -1)
                {
                    /*
                        Node already in OPEN.

                        If this new path is cheaper,
                        update its cost and parent.
                    */
                    if(open[index].cost > newcost)
                    {
                        open[index].cost = newcost;
                        open[index].parent = n.state;
                    }
                }
                else
                {
                    /*
                        Node is not in OPEN.
                        Add it.
                    */
                    newnode.state = i;
                    newnode.parent = n.state;
                    newnode.cost = newcost;

                    addOpen(open,
                            &opensize,
                            newnode);
                }
            }
        }
    }

    printf("\nGoal not found.\n");

    return 0;
}