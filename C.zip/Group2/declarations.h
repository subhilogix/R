#ifndef DECLARATIONS_H
#define DECLARATIONS_H

#define N 11
#define MAX_OPEN 100
#define MAX_EDGES 10


/* ---------- GRAPH ---------- */

typedef struct
{
    int cost;
    int next_node;
} Edge;


typedef struct
{
    Edge e[MAX_EDGES];
    int count;
} Adjlist;


/* ---------- SEARCH NODE ---------- */

typedef struct
{
    int node;
    int parent;
    int cost;
    int heuristic;
} Node;

int heuristic[MAX_OPEN];

/* ---------- PRIORITY QUEUE ---------- */

typedef struct
{
    Node data[MAX_OPEN];
    int size;
} PriorityQueue;


/* ---------- GRAPH FUNCTIONS ---------- */

void initialize_Graph(Adjlist graph[N]);

void add_Edge(Adjlist graph[N],
              int current,
              int nei,
              int cost);

void display_Graph(Adjlist graph[N]);


/* ---------- PRIORITY QUEUE FUNCTIONS ---------- */

void initialize_PQ(PriorityQueue *pq);

void enqueue(PriorityQueue *pq, Node n);

Node dequeue(PriorityQueue *pq,int mode);

int isEmpty(PriorityQueue *pq);


/* ---------- SEARCH FUNCTIONS ---------- */

int is_in_close(Node closed[],
                int closedsize,
                int n);

void add_Closed(Node closed[],
                int *closedsize,
                Node n);

void move_Gen(Adjlist graph[N],
              int curr,
              Edge successor[],
              int *count);

int GoalTest(int node, int goal);

void printNode(int node);

void printPath(Node closed[],
               int closedsize,
               int start,
               int goal);

#endif