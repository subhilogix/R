#include <stdio.h>
#include "declarations.h"
int main()
{
int graph[N][N];
NodePair open[MAX_OPEN];
NodePair closed[MAX_OPEN];
int openSize;
int closedSize;
int start = 0;
int goal = 7;
int limit;
int successors[N];
int count;
int i;
NodePair n;
int has_successors;
NodePair newNode;
initializeGraph(graph);
printf("Enter depth limit: ");
scanf("%d", &limit);
initializeOpen(open, &openSize);
closedSize = 0;
open[openSize].state = start;
open[openSize].parent = -1;
open[openSize].depth = 0;
openSize++;
printf("\nDLS Traversal:\n");
while (openSize > 0)
{
    n = removeFront(open, &openSize);
    printf(" ");
    printNode(n.state);
    if (GoalTest(n.state, goal))
    {
        addClosed(closed, &closedSize, n);
        printf("\n\n");
        printPath(closed, closedSize, start, goal);
        return 0;
    }
    addClosed(closed, &closedSize, n);
    if (n.depth >= limit)
    {
        continue;
    }
    MoveGen(graph,n.state,successors,&count,&has_successors);
    for (i = count - 1; i >= 0; i--)
    {
        int s = successors[i];
        if (isInClosed(closed, closedSize, s))
            continue;
        if (isInOpen(open, openSize, s))
            continue;
        newNode.state = s;
        newNode.parent = n.state;
        newNode.depth = n.depth + 1;
        addFront(open, &openSize, newNode);
    }
}
printf("\n\nGoal not found within depth limit.\n");
return 0;
}