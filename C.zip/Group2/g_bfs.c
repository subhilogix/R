#include <stdio.h>
#include "declarations.h"

int main()
{
    Adjlist graph[N];

    PriorityQueue pq;

    Node closed[MAX_OPEN];
    int closedsize = 0;

    int start = 1;     // B
    int goal = 10;     // J

    Edge successors[MAX_EDGES];
    int count;

    Node current;
    Node newnode;

    initialize_Graph(graph);
    initialize_PQ(&pq);

    /* Starting node */

    newnode.node = start;
    newnode.parent = -1;
    newnode.cost = 0;
    newnode.heuristic = heuristic[start];

    enqueue(&pq, newnode);

    printf("GREEDY BEST-FIRST SEARCH\n\n");

    while (!isEmpty(&pq))
    {
        /*
            Mode 2:
            Priority = heuristic
        */

        current = dequeue(&pq, 2);

        printf("Expanded: %c  h = %d\n",
               'A' + current.node,
               current.heuristic);

        /*
            Goal test
        */

        if (GoalTest(current.node, goal))
        {
            add_Closed(closed,
                       &closedsize,
                       current);

            printPath(closed,
                      closedsize,
                      start,
                      goal);

            printf("Total Cost = %d\n",
                   current.cost);

            return 0;
        }

        /*
            Add current node to CLOSED
        */

        add_Closed(closed,
                   &closedsize,
                   current);

        /*
            Generate successors
        */

        move_Gen(graph,
                 current.node,
                 successors,
                 &count);

        /*
            Process successors
        */

        for (int i = 0; i < count; i++)
        {
            int next = successors[i].next_node;

            /*
                Ignore already expanded nodes
            */

            if (is_in_close(closed,
                            closedsize,
                            next))
            {
                continue;
            }

            /*
                Create new node
            */

            newnode.node = next;
            newnode.parent = current.node;

            /*
                Keep actual path cost
                even though Greedy does not
                use it for selection.
            */

            newnode.cost =
                current.cost +
                successors[i].cost;

            newnode.heuristic =
                heuristic[next];

            enqueue(&pq, newnode);
        }
    }

    printf("\nGoal not found.\n");

    return 0;
}