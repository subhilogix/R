#include<stdio.h>
#include "search.h"

int main(){
    int start,goal,current;
    printf("Enter the number of nodes: ");
    scanf("%d",&n);
    printf("Enter the adjacency matrix:");
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            scanf("%d",&graph[i][j]);
        }
    }
    printf("enter the start node :");
    scanf("%d",&start);
    printf("enter the goal node :");
    scanf("%d",&goal);
    addOpen(start);

    while(opensize>0){
        current=removeOpen();
        if(goalTest(current,goal)){
            printf("Goal found : %d\n",current);
            return 0;
        }
        addClosed(current);
        moveGen(current);
    }
    printf("Goal not found");
    

    return 0;
}