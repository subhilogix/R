#include<stdio.h>
#include "search.h"
int main(){
    int start,limit,goal,current;
    printf("enter the number of nodes :");
    scanf("%d",&n);
    printf("enter the adjacency matrix");
    for (int i=0;i<0;i++){
        for(int j=0;j<n;j++){
            scanf("%d",&graph[i][j]);
        }
    }
    printf("enter the start node :");
    scanf("%d",&start);
    printf("enter the goal node : ");
    scanf("%d",&goal);
    printf("enter the depth limit :");
    scanf("%d",&limit);
    depth[start]=0;
    addOpen(start);
    while(opensize>0){
        current=removeOpen();
        printf("visiting the node %d at depth %d",current,depth[current]);
        if(goalTest(current,goal)){
            printf("Goal found");
            return 0;
        }
        addClosed(current);
        if(depth[current]<limit){
            moveGen(current);
        }
    }
    printf("Goal not found withint the depth limit");

}