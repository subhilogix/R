#include<stdio.h>
#include<limits.h>
#define MAX_NODES 50
#define MAX_CHILDREN 10
typedef struct{
    int childcount;
    int children[MAX_NODES];
    int terminal;
    int value;
}Node;
Node tree[MAX_NODES];
typedef struct{
    int bestmove;
    int bestvalue;
}Return;
Return ab(int child,int alpha,int beta,int mp){
    if(tree[child].terminal==1){
        Return r;
        r.bestvalue=tree[child].value;
        r.bestmove=-1;
        return r;
    }

    if(mp){
        int bv=INT_MIN;
        int bm=-1;
        for(int i=0;i<tree[child].childcount;i++){
            Return r;
            r=ab(tree[child].children[i],alpha,beta,0);
            if(r.bestvalue>bv){
                bv=r.bestvalue;
                bm=tree[child].children[i];
            }
            if(bv>alpha){
                alpha=bv;
            }
            if(beta<=alpha){
                printf("Remaining children of node %d are pruned\n",child);
                break;
            }
        }
        Return ans;
        ans.bestvalue=bv;
        ans.bestmove=bm;
        return ans;
    }
    else{
        Return r;
        int bv=INT_MAX;
        int bm=-1;
        for(int i=0;i<tree[child].childcount;i++){
            r=ab(tree[child].children[i],alpha,beta,1);
            if(r.bestvalue<bv){
                bv=r.bestvalue;
                bm=tree[child].children[i];
            }
            if(bv<beta){
                beta=bv;
            }
            if(beta<=alpha){
                printf("Remaining children of node %d are pruned \n",child);
                break;
            }
        }
        Return ans;
        ans.bestvalue=bv;
        ans.bestmove=bm;
        return ans;
    }

}
int main(){
    tree[1].childcount=2;
    tree[1].children[0]=2;
    tree[1].children[1]=3;

    tree[2].childcount=2;
    tree[2].children[0]=4;
    tree[2].children[1]=5;

    tree[3].childcount=2;
    tree[3].children[0]=6;
    tree[3].children[1]=7;

    tree[4].childcount=2;
    tree[4].children[0]=8;
    tree[4].children[1]=9;
    
    tree[8].terminal=1;
    tree[8].value=4;
    tree[9].terminal=1;
    tree[9].value=7;

    tree[5].childcount=2;
    tree[5].children[0]=10;
    tree[5].children[1]=11;

    tree[10].terminal=1;
    tree[10].value=2;
    tree[11].terminal=1;
    tree[11].value=9;

    tree[6].childcount=2;
    tree[6].children[0]=12;
    tree[6].children[1]=13;
    
    tree[12].terminal=1;
    tree[12].value=6;
    tree[13].terminal=1;
    tree[13].value=1;

    tree[7].childcount=2;
    tree[7].children[0]=14;
    tree[7].children[1]=15;
    tree[14].terminal=1;
    tree[15].terminal=1;
    tree[14].value=8;
    tree[15].value=5;
    Return r=ab(1,INT_MIN,INT_MAX,1);
    printf("BEST VALUE :%d\n",r.bestvalue);
    printf("BEST MOVE :%d\n",r.bestmove);
    return 0;
}