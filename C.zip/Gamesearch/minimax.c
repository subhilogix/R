#include <stdio.h>
#include <limits.h>

#define MAX_CHILDREN 10
#define MAX_NODES 50

typedef struct
{
    int children[MAX_CHILDREN];
    int childCount;
    int value;
    int terminal;
} Node;

Node tree[MAX_NODES];

/*
    Structure to return:
    - bestValue  -> minimax value
    - bestMove   -> child node that gives that value
*/
typedef struct
{
    int bestValue;
    int bestMove;
} Result;


Result minimax(int node, int maximizingPlayer)
{
    // Terminal node
    if (tree[node].terminal)
    {
        Result result;
        result.bestValue = tree[node].value;
        result.bestMove = -1;
        return result;
    }
    // MAX player's turn
    if (maximizingPlayer)
    {
        int bestValue = INT_MIN;
        int bestMove = -1;
        for (int i = 0; i < tree[node].childCount; i++)
        {
            int child = tree[node].children[i];
            Result result = minimax(child, 0);
            if (result.bestValue > bestValue)
            {
                bestValue = result.bestValue;
                bestMove = child;
            }
        }
        Result answer;
        answer.bestValue = bestValue;
        answer.bestMove = bestMove;
        return answer;
    }
    // MIN player's turn
    else
    {
        int bestValue = INT_MAX;
        int bestMove = -1;
        for (int i = 0; i < tree[node].childCount; i++)
        {
            int child = tree[node].children[i];
            Result result = minimax(child, 1);
            if (result.bestValue < bestValue)
            {
                bestValue = result.bestValue;
                bestMove = child;
            }
        }
        Result answer;
        answer.bestValue = bestValue;
        answer.bestMove = bestMove;
        return answer;
    }
}
int main()
{
    /*
                 0 MAX
               /       \
          1 MIN         2 MIN
          /  \          /  \
         3    4        5    6

         Values:
         3 = 3
         4 = 5
         5 = 2
         6 = 9
    */


    // Root
    tree[0].childCount = 2;
    tree[0].children[0] = 1;
    tree[0].children[1] = 2;


    // Node 1
    tree[1].childCount = 2;
    tree[1].children[0] = 3;
    tree[1].children[1] = 4;


    // Node 2
    tree[2].childCount = 2;
    tree[2].children[0] = 5;
    tree[2].children[1] = 6;


    // Terminal nodes
    tree[3].terminal = 1;
    tree[3].value = 3;

    tree[4].terminal = 1;
    tree[4].value = 5;

    tree[5].terminal = 1;
    tree[5].value = 2;

    tree[6].terminal = 1;
    tree[6].value = 9;


    // Start Minimax from root
    Result result = minimax(0, 1);


    printf("Best value = %d\n", result.bestValue);
    printf("Best move  = Node %d\n", result.bestMove);


    return 0;
}