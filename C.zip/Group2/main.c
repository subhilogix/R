#include <stdio.h>
#include "declarations.h"


/* =====================================================
   GRAPH FUNCTIONS
   ===================================================== */

void initialize_Graph(Adjlist graph[N])
{
    for (int i = 0; i < N; i++)
    {
        graph[i].count = 0;
    }
}


void add_Edge(Adjlist graph[N],
              int current,
              int nei,
              int cost)
{
    int index = graph[current].count;

    graph[current].e[index].next_node = nei;
    graph[current].e[index].cost = cost;

    graph[current].count++;
}


void display_Graph(Adjlist graph[N])
{
    for (int i = 0; i < N; i++)
    {
        printf("\n%c -> ", 'A' + i);

        for (int j = 0; j < graph[i].count; j++)
        {
            printf("%c(%d) ",
                   'A' + graph[i].e[j].next_node,
                   graph[i].e[j].cost);
        }
    }

    printf("\n");
}


/* =====================================================
   PRIORITY QUEUE FUNCTIONS
   ===================================================== */

void initialize_PQ(PriorityQueue *pq)
{
    pq->size = 0;
}


int isEmpty(PriorityQueue *pq)
{
    return pq->size == 0;
}


void enqueue(PriorityQueue *pq, Node n)
{
    if (pq->size >= MAX_OPEN)
    {
        printf("\nPriority Queue is full!");
        return;
    }

    pq->data[pq->size] = n;
    pq->size++;
}


Node dequeue(PriorityQueue *pq, int mode)
{
    Node result;

    int minIndex = 0;

    for (int i = 1; i < pq->size; i++)
    {
        int currentPriority;
        int minPriority;


        /* ---------------- UCS ---------------- */

        if (mode == 1)
        {
            currentPriority = pq->data[i].cost;
            minPriority = pq->data[minIndex].cost;
        }


        /* -------- GREEDY BEST FIRST -------- */

        else if (mode == 2)
        {
            currentPriority = pq->data[i].heuristic;
            minPriority = pq->data[minIndex].heuristic;
        }


        /* ---------------- A* ---------------- */

        else
        {
            currentPriority =
                pq->data[i].cost +
                pq->data[i].heuristic;

            minPriority =
                pq->data[minIndex].cost +
                pq->data[minIndex].heuristic;
        }


        /* Compare priorities */

        if (currentPriority < minPriority)
        {
            minIndex = i;
        }
    }


    /* Get selected node */

    result = pq->data[minIndex];


    /* Remove selected node */

    for (int i = minIndex;
         i < pq->size - 1;
         i++)
    {
        pq->data[i] = pq->data[i + 1];
    }

    pq->size--;

    return result;
}


/* =====================================================
   SEARCH FUNCTIONS
   ===================================================== */

int is_in_close(Node closed[],
                int closedsize,
                int n)
{
    for (int i = 0; i < closedsize; i++)
    {
        if (closed[i].node == n)
        {
            return 1;
        }
    }

    return 0;
}


void add_Closed(Node closed[],
                int *closedsize,
                Node n)
{
    if (*closedsize < N)
    {
        closed[*closedsize] = n;
        (*closedsize)++;
    }
}


void move_Gen(Adjlist graph[N],
              int curr,
              Edge successor[],
              int *count)
{
    *count = 0;

    for (int i = 0;
         i < graph[curr].count;
         i++)
    {
        successor[*count] = graph[curr].e[i];
        (*count)++;
    }
}


int GoalTest(int node, int goal)
{
    return node == goal;
}


void printNode(int node)
{
    printf("%c", 'A' + node);
}


void printPath(Node closed[],
               int closedsize,
               int start,
               int goal)
{
    int path[N];
    int pathSize = 0;

    int current = goal;

    while (current != -1)
    {
        path[pathSize++] = current;

        if (current == start)
        {
            break;
        }

        int found = 0;

        for (int i = 0;
             i < closedsize;
             i++)
        {
            if (closed[i].node == current)
            {
                current = closed[i].parent;
                found = 1;
                break;
            }
        }

        if (!found)
        {
            printf("\nPath not found.");
            return;
        }
    }


    printf("\nSolution Path: ");

    for (int i = pathSize - 1;
         i >= 0;
         i--)
    {
        printf("%c", 'A' + path[i]);

        if (i != 0)
        {
            printf(" -> ");
        }
    }

    printf("\n");
}