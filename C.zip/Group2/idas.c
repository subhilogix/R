#include <stdio.h>
#include "declarations.h"

int goal;
int threshold;
int next_threshold;


/* =====================================================
   IDA* SEARCH
   ===================================================== */

int ida_search(Adjlist graph[N],
               int node,
               int g,
               int parent,
               int path[],
               int depth)
{
    int f;

    Edge successors[MAX_EDGES];
    int count;


    /*
        f(n) = g(n) + h(n)
    */

    f = g + heuristic[node];


    /*
        Threshold exceeded
    */

    if (f > threshold)
    {
        if (f < next_threshold)
        {
            next_threshold = f;
        }

        return 0;
    }


    /*
        Store node in current path
    */

    path[depth] = node;

    printf("%c ", 'A' + node);


    /*
        Goal test
    */

    if (GoalTest(node, goal))
    {
        return 1;
    }


    /*
        Generate successors
    */

    move_Gen(graph,
             node,
             successors,
             &count);


    /*
        DFS through successors
    */

    for (int i = 0; i < count; i++)
    {
        int next =
            successors[i].next_node;

        int newg =
            g + successors[i].cost;


        /*
            Don't immediately go back
            to the parent.
        */

        if (next == parent)
        {
            continue;
        }


        /*
            Recursive IDA* search
        */

        if (ida_search(graph,
                       next,
                       newg,
                       node,
                       path,
                       depth + 1))
        {
            return 1;
        }
    }

    return 0;
}


/* =====================================================
   MAIN
   ===================================================== */

int main()
{
    Adjlist graph[N];

    int start = 1;     // B

    int path[N];

    int found;


    initialize_Graph(graph);

    goal = 10;         // J


    /*
        Initial threshold

        threshold = f(start)

                  = g(start) + h(start)

                  = 0 + h(start)
    */

    threshold = heuristic[start];


    printf("IDA* SEARCH ALGORITHM\n");


    while (1)
    {
        /*
            Reset next threshold
        */

        next_threshold = 999999;


        printf("\n\nThreshold = %d\n",
               threshold);

        printf("Traversal: ");


        /*
            Start depth-first search
        */

        found = ida_search(graph,
                           start,
                           0,
                           -1,
                           path,
                           0);


        /*
            Goal found
        */

        if (found)
        {
            printf("\n\nSolution Path: ");

            for (int i = 0; i < N; i++)
            {
                printf("%c",
                       'A' + path[i]);

                if (path[i] == goal)
                {
                    break;
                }

                printf(" -> ");
            }

            printf("\n");

            return 0;
        }


        /*
            No more possible threshold
        */

        if (next_threshold == 999999)
        {
            printf("\nGoal not found.\n");

            return 0;
        }


        /*
            Increase threshold
        */

        threshold = next_threshold;
    }

    return 0;
}