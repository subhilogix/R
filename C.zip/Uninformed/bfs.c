#include <stdio.h>
#include "declarations.h"

int main()
{
    int graph[N][N];

    NodePair open[MAX_OPEN];
    NodePair closed[MAX_OPEN];

    int openSize;
    int closedSize;

    int start = 0;
    int goal = 7;

    int successors[N];
    int count;

    NodePair n;
    NodePair newNode;

    int i;


    /* Initialize graph */
    initializeGraph(graph);


    /* Initialize OPEN */
    openSize = 0;
    /* Initialize CLOSED */
    closedSize = 0;


    /* Add START node to OPEN */
    open[openSize].state = start;
    open[openSize].parent = -1;
    open[openSize].depth = 0;

    openSize++;
    int has_successors;

    printf("BFS TRAVERSAL:\n");


    while (openSize > 0)
    {
        /* Remove from FRONT */
        n = removeFront(open, &openSize);


        printf("\nExpanding: ");
        printNode(n.state);


        /* Goal test */
        if (GoalTest(n.state, goal))
        {
            addClosed(closed, &closedSize, n);

            printf("\n\nGOAL FOUND!\n");

            printPath(closed, closedSize,
                      start, goal);

            return 0;
        }


        /* Add current node to CLOSED */
        addClosed(closed, &closedSize, n);


        /* Generate successors */
        MoveGen(graph, n.state,
                successors, &count,&has_successors);


        printf("\nSuccessors of ");
        printNode(n.state);
        printf(": ");


        for (i = 0; i < count; i++)
        {
            printNode(successors[i]);
            printf(" ");
        }

        printf("\n");


        /*
            BFS:
            Add successors to BACK
        */

        for (i = 0; i < count; i++)
        {
            int s = successors[i];


            /* Already explored */
            if (isInClosed(closed,
                           closedSize, s))
            {
                continue;
            }


            /* Already waiting in OPEN */
            if (isInOpen(open,
                         openSize, s))
            {
                continue;
            }


            newNode.state = s;
            newNode.parent = n.state;
            newNode.depth = n.depth + 1;


            addBack(open,
                    &openSize,
                    newNode);
        }


        /* Show OPEN */
        printOpen(open, openSize);
    }


    printf("\nGoal not found.\n");

    return 0;
}