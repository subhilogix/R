#include <stdio.h>
#include <stdlib.h>

#define ROWS 5
#define COLS 5
#define MAX_NODES 100
#define BEAM_WIDTH 2

typedef struct
{
    int x;
    int y;
    int g;
    int h;
    int f;
    int parent;
} Node;

int grid[ROWS][COLS] =
{
    {0, 0, 0, 0, 0},
    {0, 1, 1, 1, 0},
    {0, 0, 0, 0, 0},
    {0, 1, 1, 1, 0},
    {0, 0, 0, 0, 0}
};

/* ------------------------------------------------ */
/* MANHATTAN HEURISTIC                              */
/* ------------------------------------------------ */

int heuristic(int x, int y, int goalX, int goalY)
{
    return abs(x - goalX) + abs(y - goalY);
}

/* ------------------------------------------------ */
/* GOAL TEST                                        */
/* ------------------------------------------------ */

int GoalTest(int x, int y, int goalX, int goalY)
{
    return x == goalX && y == goalY;
}

/* ------------------------------------------------ */
/* MOVE GENERATOR                                   */
/* ------------------------------------------------ */

int MoveGen(int x, int y, int successors[][2])
{
    int count = 0;

    /* Up */
    if(x - 1 >= 0 && grid[x - 1][y] == 0)
    {
        successors[count][0] = x - 1;
        successors[count][1] = y;
        count++;
    }

    /* Down */
    if(x + 1 < ROWS && grid[x + 1][y] == 0)
    {
        successors[count][0] = x + 1;
        successors[count][1] = y;
        count++;
    }

    /* Left */
    if(y - 1 >= 0 && grid[x][y - 1] == 0)
    {
        successors[count][0] = x;
        successors[count][1] = y - 1;
        count++;
    }

    /* Right */
    if(y + 1 < COLS && grid[x][y + 1] == 0)
    {
        successors[count][0] = x;
        successors[count][1] = y + 1;
        count++;
    }

    return count;
}

/* ------------------------------------------------ */
/* PRINT PATH                                       */
/* ------------------------------------------------ */

void reconstructPath(Node nodes[], int goalIndex)
{
    int path[MAX_NODES];
    int pathSize = 0;

    int current = goalIndex;

    while(current != -1)
    {
        path[pathSize] = current;
        pathSize++;

        current = nodes[current].parent;
    }

    printf("Path: ");

    for(int i = pathSize - 1; i >= 0; i--)
    {
        printf("(%d,%d)",
               nodes[path[i]].x,
               nodes[path[i]].y);

        if(i != 0)
            printf(" -> ");
    }

    printf("\n");
}

/* ================================================= */
/* A* SEARCH                                        */
/* ================================================= */

void AStar(int startX, int startY,
           int goalX, int goalY)
{
    Node open[MAX_NODES];
    Node closed[MAX_NODES];

    int openSize = 0;
    int closedSize = 0;

    int visited[ROWS][COLS] = {0};

    Node start;

    start.x = startX;
    start.y = startY;

    start.g = 0;

    start.h =
        heuristic(startX, startY,
                  goalX, goalY);

    start.f = start.g + start.h;

    start.parent = -1;

    open[openSize++] = start;

    printf("\n================ A* SEARCH ================\n");

    while(openSize > 0)
    {
        /* Find minimum f(n) */

        int minIndex = 0;

        for(int i = 1; i < openSize; i++)
        {
            if(open[i].f < open[minIndex].f)
            {
                minIndex = i;
            }
        }

        Node current = open[minIndex];

        /* Remove from OPEN */

        for(int i = minIndex;
            i < openSize - 1;
            i++)
        {
            open[i] = open[i + 1];
        }

        openSize--;

        printf("Expanding (%d,%d)  g=%d h=%d f=%d\n",
               current.x,
               current.y,
               current.g,
               current.h,
               current.f);

        /* Goal test */

        if(GoalTest(current.x,
                    current.y,
                    goalX,
                    goalY))
        {
            closed[closedSize] = current;

            printf("\nGoal found!\n");

            reconstructPath(closed,
                             closedSize);

            printf("Path Cost = %d\n",
                   current.g);

            return;
        }

        visited[current.x][current.y] = 1;

        closed[closedSize++] = current;

        /* Generate successors */

        int successors[4][2];

        int count =
            MoveGen(current.x,
                    current.y,
                    successors);

        for(int i = 0; i < count; i++)
        {
            int nx = successors[i][0];
            int ny = successors[i][1];

            if(visited[nx][ny])
                continue;

            Node child;

            child.x = nx;
            child.y = ny;

            child.g = current.g + 1;

            child.h =
                heuristic(nx, ny,
                          goalX, goalY);

            child.f =
                child.g + child.h;

            child.parent =
                closedSize - 1;

            open[openSize++] = child;
        }
    }

    printf("Goal not found.\n");
}

/* ================================================= */
/* BEAM SEARCH                                      */
/* ================================================= */

void BeamSearch(int startX, int startY,
                int goalX, int goalY)
{
    Node beam[MAX_BEAM];

    int beamSize = 1;

    beam[0].x = startX;
    beam[0].y = startY;

    beam[0].g = 0;

    beam[0].h =
        heuristic(startX, startY,
                  goalX, goalY);

    beam[0].f =
        beam[0].h;

    beam[0].parent = -1;

    printf("\n============= BEAM SEARCH =============\n");

    while(beamSize > 0)
    {
        printf("\nCurrent Beam: ");

        for(int i = 0; i < beamSize; i++)
        {
            printf("(%d,%d)[h=%d] ",
                   beam[i].x,
                   beam[i].y,
                   beam[i].h);
        }

        /* Goal test */

        for(int i = 0; i < beamSize; i++)
        {
            if(GoalTest(beam[i].x,
                        beam[i].y,
                        goalX,
                        goalY))
            {
                printf("\n\nGoal found at (%d,%d)\n",
                       goalX,
                       goalY);

                printf("Beam Search reached the goal.\n");

                return;
            }
        }

        Node candidates[MAX_NODES];

        int candidateCount = 0;

        /* Expand every node in current beam */

        for(int i = 0; i < beamSize; i++)
        {
            int successors[4][2];

            int count =
                MoveGen(beam[i].x,
                        beam[i].y,
                        successors);

            for(int j = 0; j < count; j++)
            {
                Node child;

                child.x = successors[j][0];
                child.y = successors[j][1];

                child.g = beam[i].g + 1;

                child.h =
                    heuristic(child.x,
                              child.y,
                              goalX,
                              goalY);

                child.f =
                    child.g + child.h;

                child.parent = -1;

                candidates[candidateCount++] =
                    child;
            }
        }

        /* Sort according to heuristic */

        for(int i = 0;
            i < candidateCount - 1;
            i++)
        {
            for(int j = i + 1;
                j < candidateCount;
                j++)
            {
                if(candidates[j].h <
                   candidates[i].h)
                {
                    Node temp =
                        candidates[i];

                    candidates[i] =
                        candidates[j];

                    candidates[j] =
                        temp;
                }
            }
        }

        /* Keep only best BEAM_WIDTH nodes */

        beamSize = 0;

        for(int i = 0;
            i < candidateCount &&
            i < BEAM_WIDTH;
            i++)
        {
            beam[beamSize++] =
                candidates[i];
        }
    }

    printf("\nGoal not found.\n");
}

/* ================================================= */
/* MAIN                                             */
/* ================================================= */

int main()
{
    int startX = 0;
    int startY = 0;

    int goalX = 4;
    int goalY = 4;

    printf("START : (%d,%d)\n",
           startX, startY);

    printf("GOAL  : (%d,%d)\n",
           goalX, goalY);

    printf("\nHeuristic = Manhattan Distance\n");

    AStar(startX, startY,
          goalX, goalY);

    BeamSearch(startX, startY,
               goalX, goalY);

    return 0;
}