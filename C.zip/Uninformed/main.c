#include <stdio.h>
#include "declarations.h"
void initializeGraph(int graph[N][N])
{
    int i, j;
    for (i = 0; i < N; i++)
    {
        for (j = 0; j < N; j++)
        {
            graph[i][j] = 0;
        }
    }
    graph[0][1] = graph[1][0] = 1; 
    graph[0][4] = graph[4][0] = 1; 
    graph[1][2] = graph[2][1] = 1;  
    graph[1][4] = graph[4][1] = 1;  
    graph[2][3] = graph[3][2] = 1; 
    graph[2][5] = graph[5][2] = 1;  
    graph[4][5] = graph[5][4] = 1;  
    graph[5][6] = graph[6][5] = 1; 
    graph[6][7] = graph[7][6] = 1;  
}

int MoveGen(int graph[N][N],int state,int successors[],int *count,int *has_successors)
{
    int i;
    *count = 0;
    *has_successors=0;
    for (i = 0; i < N; i++)
    {
        if (graph[state][i] == 1)
        {
            successors[*count] = i;
            (*count)++;
            *has_successors=1;

        }
    }
    return *has_successors;
}

int GoalTest(int state, int goal)
{
    return state == goal;
}


void addFront(NodePair open[],int *size,NodePair node)
{
    int i;
    if (*size >= MAX_OPEN)
        return;
    for (i = *size; i > 0; i--)
    {
        open[i] = open[i - 1];
    }
    open[0] = node;
    (*size)++;
}

void addBack(NodePair open[],int *size,NodePair node)
{
    if (*size >= MAX_OPEN)
        return;
    open[*size] = node;
    (*size)++;
}

NodePair removeFront(NodePair open[],int *size)
{
    NodePair selected;
    int i;
    selected = open[0];
    for (i = 0; i < *size - 1; i++)
    {
        open[i] = open[i + 1];
    }
    (*size)--;
    return selected;
}
int isInOpen(NodePair open[],int size,int state)
{
    int i;
    for (i = 0; i < size; i++)
    {
        if (open[i].state == state)
        {
            return 1;
        }
    }
    return 0;
}
int isInClosed(NodePair closed[],int size,int state)
{
    int i;
    for (i = 0; i < size; i++)
    {
        if (closed[i].state == state)
        {
            return 1;
        }
    }
    return 0;
}
void addClosed(NodePair closed[],int *size,NodePair node)
{
    if (*size >= MAX_OPEN)
        return;
    closed[*size] = node;
    (*size)++;
}

void printNode(int state)
{
    char nodes[N] =
    {
        'S', 'A', 'B', 'C',
        'D', 'E', 'F', 'G'
    };
    printf("%c", nodes[state]);
}
void printOpen(NodePair open[], int size)
{
    int i;
    printf("OPEN: ");
    for (i = 0; i < size; i++)
    {
        printNode(open[i].state);
        printf(" ");
    }
    printf("\n");
}

void printPath(NodePair closed[],int closedSize,int start,int goal)
{
    int path[N];
    int pathSize = 0;
    int current = goal;
    int found;
    int i;
    int j;

    while (current != start)
    {
        path[pathSize] = current;
        pathSize++;
        found = 0;
        for (i = 0; i < closedSize; i++)
        {
            if (closed[i].state == current)
            {
                current = closed[i].parent;
                found = 1;
                break;
            }
        }

        if (!found)
        {
            printf("Path reconstruction failed.\n");
            return;
        }
    }

    path[pathSize] = start;
    pathSize++;
    printf("Path: ");
    for (j = pathSize - 1; j >= 0; j--)
    {
        printNode(path[j]);
        if (j != 0)
            printf(" -> ");
    }

    printf("\n");
}