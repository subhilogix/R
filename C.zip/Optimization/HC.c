#include <stdio.h>
#define MAX 10
int graph[MAX][MAX];
int value[MAX];
void hillClimbing(int start)
{
    int current = start;
    while (1)
    {
        int best = current;
        printf("\nCurrent Node: %d (value = %d)",
               current, value[current]);
        // Check all neighbors
        for (int i = 0; i < MAX; i++)
        {
            if (graph[current][i] == 1)
            {
                printf("\n  Neighbor: %d (value = %d)",i, value[i]);
                if (value[i] > value[best])
                {
                    best = i;
                }
            }
        }
        // No better neighbor
        if (best == current)
        {
            printf("\nNo better neighbor.");
            printf("\nHill Climbing stopped.");
            break;
        }
        // Move to better neighbor
        printf("\nMoving to Node %d", best);
        current = best;
    }
    printf("\n\nFinal Node = %d", current);
    printf("\nFinal Value = %d\n", value[current]);
}

int main()
{
    // Values of nodes
    value[0] = 2;
    value[1] = 4;
    value[2] = 6;
    value[3] = 8;
    value[4] = 10;
    // Connections
    graph[0][1] = 1;
    graph[1][0] = 1;
    graph[1][2] = 1;
    graph[2][1] = 1;
    graph[2][3] = 1;
    graph[3][2] = 1;
    graph[3][4] = 1;
    graph[4][3] = 1;
    hillClimbing(0);
    return 0;
}