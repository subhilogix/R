#include<stdio.h>
#include "declarations.h"
#include <limits.h>
int goal;
int threshold;
int next_threshold;

int ida_search(Adjlist graph[N],int node,int g,int parent,int path[],int depth)
{
    int f;
    int i;
    int count;
    Edge successors[MAX_EDGES];
    f=g+heuristic[node];
    printf("\nf value for the node %d is %d",node,f);

    if(f>threshold)
    {
        if(f<next_threshold)
        {
            next_threshold=f;
        }
        return 0;
    }
    path[depth]=node;

    // printf("%d ",node);
    if(GoalTest(node,goal))
    {
        return 1;
    }
    move_Gen(graph,node,successors,&count);
    for(i=0;i<count;i++)
    {
        int next=successors[i].next_node;
        if(next==parent)
        {
            continue;
        }
        if(ida_search(graph,next,g+successors[i].cost,node,path,depth+1))
        {
            return 1;
        }
    }
    return 0;
}

int main()
{
    Adjlist graph[N];
    int start=1;
    int path[N];
    int depth;
    int found;
    initialize_Graph(graph);
    goal=10;
    threshold=heuristic[start];
    printf("IDA* SEARCH ALGORITHM\n");
    while(1)
    {
        next_threshold=INT_MAX;
        printf("\nThreshold = %d\n",threshold);
        printf("Traversal: ");
        found=ida_search(graph,start,0,-1,path,0);
        if(found)
        {
            printf("\nPath: ");
            for(depth=0;depth<N;depth++)
            {
                printNode(path[depth]);
                if(path[depth]==goal)
                {
                    break;
                }
                printf(" -> ");
            }
            printf("\n");
            return 0;
        }

        if(next_threshold==INT_MAX)
        {
            printf("\nGoal not found.\n");
            return 0;
        }
        threshold=next_threshold;
    }
}