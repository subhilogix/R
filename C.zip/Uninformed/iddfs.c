#include <stdio.h>
#include "declarations.h"
int runDLS(int graph[N][N],int start,int goal,int limit)
{
    NodePair open[MAX_OPEN];
    NodePair closed[MAX_OPEN];
    int openSize;
    int closedSize;
    int successors[N];
    int count;
    int i;
    int has_successors;
    NodePair n;
    NodePair newNode;
    openSize=0;
    closedSize = 0;
    open[openSize].state = start;
    open[openSize].parent = -1;
    open[openSize].depth = 0;
    openSize++;
    printf("Traversal:");
    while (openSize > 0)
    {   
        n = removeFront(open, &openSize);
        printf(" ");
        printNode(n.state);
        if (GoalTest(n.state, goal))
        {
            addClosed(closed, &closedSize, n);
            printf("\n");
            printPath(closed,closedSize,start,goal);
            return 1;
        }
        addClosed(closed, &closedSize, n);
        if (n.depth >= limit)
        {
            continue;
        }
        MoveGen(graph,n.state,successors,&count,&has_successors);
        for (i = count - 1; i >= 0; i--)
        {
            int s = successors[i];
            if (isInClosed(closed, closedSize, s))
                continue;
            if (isInOpen(open, openSize, s))
                continue;
            newNode.state = s;
            newNode.parent = n.state;
            newNode.depth = n.depth + 1;
            addFront(open, &openSize, newNode);
        }
    }
    printf("\n");
    return 0;
}
int main()
{
    int graph[N][N];
    int start = 0;  
    int goal = 7;   
    int limit;
    initializeGraph(graph);
    printf("IDDFS\n");
    for (limit = 0; limit < N; limit++)
    {
        printf("\nDepth Limit = %d\n", limit);
        if (runDLS(graph,start,goal,limit))
        {
            printf("Goal found.\n");
            return 0;
        }
    }
    printf("\nGoal not found.\n");
    return 0;
}