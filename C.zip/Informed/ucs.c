#include <stdio.h>
#include "declarations.h"

int main()
{
    int graph[N][N];
    int cost[N][N];

    Node open[MAX_OPEN];
    Node closed[MAX_OPEN];

    int openSize = 0;
    int closedSize = 0;

    int start = 1;   // A
    int goal = 6;    // F

    Node n;
    Node newNode;

    initializeGraph(graph, cost);

    // Add start node
    open[openSize].state = start;
    open[openSize].parent = -1;
    open[openSize].cost = 0;

    openSize++;

    printf("UCS TRAVERSAL:\n");

    while(openSize > 0)
    {
        // Remove lowest-cost node
        n = removeMin(open, &openSize);

        printf("Expanding: ");
        printNode(n.state);
        printf("  Cost = %d\n", n.cost);

        // Goal test
        if(GoalTest(n.state, goal))
        {
            addClosed(closed, &closedSize, n);

            printf("\nGOAL FOUND!\n");

            printPath(closed, closedSize,
                      start, goal);

            printf("Total Cost: %d\n", n.cost);

            return 0;
        }

        // Add to CLOSED
        addClosed(closed, &closedSize, n);

        // Generate successors
        for(int i = 0; i < N; i++)
        {
            if(graph[n.state][i] == 1)
            {
                // Skip CLOSED
                if(isInClosed(closed, closedSize, i))
                    continue;

                newNode.state = i;
                newNode.parent = n.state;
                newNode.cost =
                    n.cost + cost[n.state][i];

                addOpen(open, &openSize, newNode);

                printf("  Adding ");
                printNode(i);
                printf(" Cost = %d\n",
                       newNode.cost);
            }
        }
    }

    printf("\nGoal not found.\n");

    return 0;
}