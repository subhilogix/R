#include<stdio.h>
#include "search.h"
void addOpen(int node){
    OPEN[opensize]=node;
    opensize++;
}

int removeOpen(){
    opensize--;
    return OPEN[opensize];
}

int removeOpenfromfirst(){
    int node=OPEN[0];
    for(int i=0;i<opensize;i++){
        OPEN[i]=OPEN[i+1];
    }
    opensize--;
    return node;

}
void addClosed(int node){
    CLOSED[closedsize]=node;
    closedsize++;
}

int isInOpen(int node){
    for(int i=0;i<opensize;i++){
        if(OPEN[i]==node){
            return 1;
        }
    }
    return 0;
}


int isInClosed(int node){
    for(int i=0;i<closedsize;i++){
        if(CLOSED[i]==node){
            return 1;
        }
    }
    return 0;
}

int goalTest(int node,int goal){
    if(node==goal){
        return 1;
    }
    return 0;
}

void moveGen(int node){
    for(int i=0;i<n;i++){
        if(graph[node][i]==1){
            if(!isInClosed(i)&& !isInOpen(i)){
                addOpen(i);
                depth[i]=depth[node]+1;
            }
        }
    }
}

