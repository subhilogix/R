#include <stdio.h>
#include <limits.h>

#define MAX 5

int graph[MAX][MAX];
int visited[MAX];

int bestCost = INT_MAX;
int bestPath[MAX];
int currentPath[MAX];

void branchAndBound(int current, int goal, int level, int cost)
{
    int i;
    // Goal reached
    if (current == goal)
    {
        if (cost < bestCost)
        {
            bestCost = cost;
            for (i = 0; i < level; i++)
                bestPath[i] = currentPath[i];
            bestPath[level] = goal;
        }
        return;
    }

    // Generate branches
    for (i = 0; i < MAX; i++)
    {
        if (graph[current][i] != 0 && visited[i] == 0)
        {
            int newCost = cost + graph[current][i];

            // Bound
            if (newCost >= bestCost)
            {
                printf("Pruned: %c -> %c\n",
                       'A' + current,
                       'A' + i);
                continue;
            }

            // Branch
            visited[i] = 1;
            currentPath[level] = i;

            branchAndBound(i, goal, level + 1, newCost);

            visited[i] = 0;
        }
    }
}

int main()
{
    // W = 0
    // A = 1
    // B = 2
    // C = 3
    // D = 4

    graph[0][1] = 10;   // W -> A
    graph[0][2] = 18;   // W -> B
    graph[0][3] = 12;   // W -> C
    graph[0][4] = 20;   // W -> D

    graph[1][2] = 15;   // A -> B
    graph[1][3] = 9;    // A -> C
    graph[1][4] = 14;   // A -> D

    graph[2][3] = 16;   // B -> C
    graph[2][4] = 8;    // B -> D

    graph[3][4] = 11;   // C -> D

    visited[0] = 1;
    currentPath[0] = 0;

    branchAndBound(0, 4, 1, 0);
    printf("\nBest Path: ");
    for (int i = 0; i <= 4; i++)
    {
        printf("%c", 'A' + bestPath[i]);

        if (bestPath[i] == 4)
            break;

        printf(" -> ");
    }

    printf("\nBest Cost: %d\n", bestCost);

    return 0;
}