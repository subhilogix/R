#ifndef DECLARATIONS_H
#define DECLARATIONS_H

#define N 11
#define MAX_OPEN 100

typedef struct
{
    int state;
    int parent;
    int cost;
} Node;

void initializeGraph(int graph[N][N], int cost[N][N]);

void addEdge(int graph[N][N], int cost[N][N],
             int u, int v, int edgeCost);

int GoalTest(int state, int goal);

void addOpen(Node open[], int *openSize, Node node);

Node removeMin(Node open[], int *openSize);

int isInOpen(Node open[], int openSize, int state);

int isInClosed(Node closed[], int closedSize, int state);

void addClosed(Node closed[], int *closedSize, Node node);

void printNode(int state);

void printPath(Node closed[], int closedSize,
               int start, int goal);

#endif