#include<stdio.h>
int graph[10][10];
int value[10];
void hc(int start){
    int current=start;
    
    while(1){
        int best=current;
        printf("CURRENT NODE :%d and its value %d\n",current,value[current]);
        for (int i=0;i<10;i++){
            if(graph[current][i]==1){
                printf("neighbour NODE :%d and  its value %d\n",i,value[i]);
                if(value[i]>value[best]){
                    best=i;
                }
            }
            
        }
        if(best==current){
            printf("no better neighbour\n");
            printf("hill climbing stopped\n");
            break;
            }
            printf("moving to node %d\n",best);
            current=best;
        }
        printf("FINAL NODE :%d and its vlaue is%d\n",current,value[current]);

    
}
int main()
{
    // Values of nodes
    value[0] = 5;   // A
    value[1] = 8;   // B
    value[2] = 6;   // C
    value[3] = 7;   // D
    value[4] = 10;  // E
    value[5] = 9;   // F
    value[6] = 12;  // G

    // Connections
    graph[0][1] = 1;   // A-B
    graph[1][0] = 1;

    graph[0][2] = 1;   // A-C
    graph[2][0] = 1;

    graph[1][3] = 1;   // B-D
    graph[3][1] = 1;

    graph[1][4] = 1;   // B-E
    graph[4][1] = 1;

    graph[2][5] = 1;   // C-F
    graph[5][2] = 1;

    graph[4][6] = 1;   // E-G
    graph[6][4] = 1;

    hc(0);

    return 0;
}