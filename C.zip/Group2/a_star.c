#include <stdio.h>
#include "declarations.h"

int main()
{
    Adjlist graph[N];

    PriorityQueue pq;

    Node closed[MAX_OPEN];
    int closedsize = 0;

    int start = 1;     // B
    int goal = 10;     // J

    Edge successors[MAX_EDGES];
    int count;

    Node current;
    Node newnode;

    initialize_Graph(graph);
    initialize_PQ(&pq);

    /* Starting node */

    newnode.node = start;
    newnode.parent = -1;
    newnode.cost = 0;
    newnode.heuristic = heuristic[start];

    enqueue(&pq, newnode);

    printf("A* SEARCH ALGORITHM\n\n");

    while (!isEmpty(&pq))
    {
        /*
            Mode 3:
            Priority = cost + heuristic

            f(n) = g(n) + h(n)
        */

        current = dequeue(&pq, 3);

        printf("Expanded: %c  g = %d  h = %d  f = %d\n",
               'A' + current.node,
               current.cost,
               current.heuristic,
               current.cost + current.heuristic);

        /*
            Goal test
        */

        if (GoalTest(current.node, goal))
        {
            add_Closed(closed,
                       &closedsize,
                       current);

            printPath(closed,
                      closedsize,
                      start,
                      goal);

            printf("Total Cost = %d\n",
                   current.cost);

            return 0;
        }

        /*
            Add current node to CLOSED
        */

        add_Closed(closed,
                   &closedsize,
                   current);

        /*
            Generate successors
        */

        move_Gen(graph,
                 current.node,
                 successors,
                 &count);

        /*
            Process successors
        */

        for (int i = 0; i < count; i++)
        {
            int next = successors[i].next_node;

            /*
                Ignore already expanded nodes
            */

            if (is_in_close(closed,
                            closedsize,
                            next))
            {
                continue;
            }

            /*
                Create new node
            */

            newnode.node = next;
            newnode.parent = current.node;

            newnode.cost =
                current.cost +
                successors[i].cost;

            newnode.heuristic =
                heuristic[next];

            enqueue(&pq, newnode);
        }
    }

    printf("\nGoal not found.\n");

    return 0;
}