#include<stdio.h>
#include "search.h"

int main(){
    int start,goal,current;
    printf("Enter the number of nodes :");
    scanf("%d",&n);
    printf("enter the adjacency matrix \n");
    for (int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            scanf("%d",&graph[i][j]);
        }
    }

    printf("Enter the start node");
    scanf("%d",&start);
    printf("Enter the goal node :");
    scanf("%d",&goal);

    addOpen(start);
    while(opensize>0){
        current=removeOpenfromfirst();
        if(goalTest(current,goal)){
            printf("Goal found");
            return 0;
        }
        addClosed(current);
        moveGen(current);
        
    }
    printf("Gola not found");
    return 0;
}