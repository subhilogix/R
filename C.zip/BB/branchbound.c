// #include <stdio.h>
// #include <limits.h>

// #define MAX_NODES 20
// #define MAX_OPEN 50
// #define INF 9999

// /* =========================
//         EDGE STRUCTURE
//    ========================= */

// typedef struct
// {
//     int next;
//     int cost;
// } Edge;


// /* =========================
//         NODE STRUCTURE
//    ========================= */

// typedef struct
// {
//     int node;
//     int parent;
//     int cost;
//     int bound;
// } Node;


// /* =========================
//         GRAPH
//    ========================= */

// Edge graph[MAX_NODES][MAX_NODES];

// int edgeCount[MAX_NODES];


// /* =========================
//         OPEN LIST
//    ========================= */

// Node open[MAX_OPEN];

// int openSize = 0;


// /* =========================
//         PARENT / COST ARRAYS
//    ========================= */

// int parent[MAX_NODES];

// int bestNodeCost[MAX_NODES];

// int bestCost = INF;

// int goal;


// /* =========================
//         ADD EDGE
//    ========================= */

// void addEdge(int from, int to, int cost)
// {
//     graph[from][edgeCount[from]].next = to;

//     graph[from][edgeCount[from]].cost = cost;

//     edgeCount[from]++;
// }


// /* =========================
//         ADD TO OPEN
//    ========================= */

// void addOpen(Node newNode)
// {
//     open[openSize] = newNode;

//     openSize++;
// }


// /* =========================
//         REMOVE LOWEST BOUND
//    ========================= */

// Node removeBest()
// {
//     int bestIndex = 0;

//     for (int i = 1; i < openSize; i++)
//     {
//         if (open[i].bound < open[bestIndex].bound)
//         {
//             bestIndex = i;
//         }
//     }

//     Node bestNode = open[bestIndex];


//     /* Shift remaining nodes */

//     for (int i = bestIndex; i < openSize - 1; i++)
//     {
//         open[i] = open[i + 1];
//     }

//     openSize--;

//     return bestNode;
// }


// /* =========================
//         GOAL TEST
//    ========================= */

// int goalTest(int node)
// {
//     return node == goal;
// }


// /* =========================
//         PRINT PATH
//    ========================= */

// void printPath(int node)
// {
//     int path[MAX_NODES];
//     int pathSize = 0;
//     int current = node;
//     while (current != -1)
//     {
//         path[pathSize] = current;
//         pathSize++;
//         current = parent[current];
//     }
//     printf("\nSolution Path: ");

//     for (int i = pathSize - 1; i >= 0; i--)
//     {
//         printf("%c", 'A' + path[i]);

//         if (i != 0)
//         {
//             printf(" -> ");
//         }
//     }

//     printf("\n");
// }


// /* =========================
//         BRANCH AND BOUND
//    ========================= */

// void branchAndBound(int start, int target)
// {
//     goal = target;
//     bestCost = INF;
//     openSize = 0;
//     /*
//         Initialize parent and
//         best cost arrays
//     */
//     for (int i = 0; i < MAX_NODES; i++)
//     {
//         parent[i] = -1;

//         bestNodeCost[i] = INF;
//     }

//     /*
//         Starting node has cost 0
//     */
//     bestNodeCost[start] = 0;

//     /*
//         Create start node
//     */

//     Node startNode;

//     startNode.node = start;

//     startNode.parent = -1;

//     startNode.cost = 0;

//     startNode.bound = 0;
//     addOpen(startNode);
//     printf("Starting Branch and Bound...\n");
//     while (openSize > 0)
//     {
//         /*
//             Select node with
//             smallest bound
//         */
//         Node current = removeBest();


//         printf("\nExpanding Node %c",
//                'A' + current.node);

//         printf(" | Cost = %d",
//                current.cost);

//         printf(" | Bound = %d\n",
//                current.bound);


//         /*
//             If this branch cannot
//             improve current solution
//         */

//         if (current.bound >= bestCost)
//         {
//             printf("Branch at Node %c is PRUNED "
//                    "(bound %d >= best cost %d)\n",
//                    'A' + current.node,
//                    current.bound,
//                    bestCost);

//             continue;
//         }


//         /*
//             Goal test
//         */

//         if (goalTest(current.node))
//         {
//             printf("Goal reached at Node %c\n",
//                    'A' + current.node);


//             if (current.cost < bestCost)
//             {
//                 bestCost = current.cost;

//                 /*
//                     Store parent of the
//                     current best solution
//                 */

//                 parent[current.node] =
//                     current.parent;


//                 printf("New Best Cost = %d\n",
//                        bestCost);
//             }

//             continue;
//         }


//         /*
//             Generate successors
//         */

//         for (int i = 0;i < edgeCount[current.node];i++)
//         {
//             int next =
//                 graph[current.node][i].next;
//             int edgeCost =
//                 graph[current.node][i].cost;
//             int newCost =
//                 current.cost + edgeCost;


//             /*
//                 For our basic version:

//                 Bound = current cost
//             */

//             int newBound = newCost;


//             printf("  Checking %c -> %c",
//                    'A' + current.node,
//                    'A' + next);

//             printf(" | Cost = %d",
//                    newCost);

//             printf(" | Bound = %d\n",
//                    newBound);


//             /*
//                 Branch and Bound pruning
//             */

//             if (newBound >= bestCost)
//             {
//                 printf("  ---> Node %c is PRUNED "
//                        "(bound %d >= best cost %d)\n",
//                        'A' + next,
//                        newBound,
//                        bestCost);

//                 continue;
//             }


//             /*
//                 Only add this node if
//                 we found a cheaper path
//             */

//             if (newCost < bestNodeCost[next])
//             {
//                 /*
//                     Update best known cost
//                 */

//                 bestNodeCost[next] = newCost;


//                 /*
//                     Update parent
//                 */

//                 parent[next] = current.node;


//                 /*
//                     Create child
//                 */

//                 Node child;

//                 child.node = next;

//                 child.parent = current.node;

//                 child.cost = newCost;

//                 child.bound = newBound;


//                 /*
//                     Add to OPEN
//                 */

//                 addOpen(child);


//                 printf("  ---> Node %c added to OPEN\n",
//                        'A' + next);
//             }
//             else
//             {
//                 printf("  ---> Node %c ignored "
//                        "(not a better path)\n",
//                        'A' + next);
//             }
//         }
//     }


//     /* =========================
//             FINAL RESULT
//        ========================= */

//     printf("\n=================================\n");

//     printf("       FINAL RESULT\n");

//     printf("=================================\n");


//     if (bestCost != INF)
//     {
//         printf("Best Cost = %d\n",
//                bestCost);

//         printPath(goal);
//     }
//     else
//     {
//         printf("No solution found.\n");
//     }
// }


// /* =========================
//             MAIN
//    ========================= */

// int main()
// {
//     /*
     
//                     A
//                   /   \
//                 2/     \5
//                 B       C
//               /  \       \
//             3/    \6      \2
//             D      E       F
//              \              \
//              4\              \1
//                G <-----------

//     */


//     /*
//         A -> B = 2
//         A -> C = 5
//     */

//     addEdge(0, 1, 2);

//     addEdge(0, 2, 5);


//     /*
//         B -> D = 3
//         B -> E = 6
//     */

//     addEdge(1, 3, 3);

//     addEdge(1, 4, 6);


//     /*
//         C -> F = 2
//     */

//     addEdge(2, 5, 2);


//     /*
//         D -> G = 4
//     */

//     addEdge(3, 6, 4);


//     /*
//         F -> G = 1
//     */

//     addEdge(5, 6, 1);


//     /*
//         E -> G = 2
//     */

//     addEdge(4, 6, 2);


//     /*
//         Start = A = 0
//         Goal  = G = 6
//     */

//     branchAndBound(0, 6);


//     return 0;
// }

#include <stdio.h>
#include <limits.h>

#define MAX 10

int graph[MAX][MAX];
int visited[MAX];
int n;

int bestCost = INT_MAX;
int bestPath[MAX];
int currentPath[MAX];

void branchAndBound(int current, int goal, int level, int cost)
{
    int i;

    // Goal reached
    if (current == goal)
    {
        if (cost < bestCost)
        {
            bestCost = cost;
            for (i = 0; i < level; i++)
                bestPath[i] = currentPath[i];
            bestPath[level] = goal;
        }

        return;
    }

    // Branch and Bound
    for (i = 0; i < n; i++)
    {
        if (graph[current][i] != 0 && visited[i] == 0)
        {
            int newCost = cost + graph[current][i];

            // Bound
            if (newCost >= bestCost)
            {
                printf("Pruned: %c -> %c\n",
                       'A' + current, 'A' + i);
                continue;
            }

            // Branch
            visited[i] = 1;
            currentPath[level] = i;

            branchAndBound(i, goal, level + 1, newCost);

            visited[i] = 0;
        }
    }
}

int main()
{
    int i;

    /*
              A
             / \
            2   5
           /     \
          B       C
         / \       \
        3   6       2
       /             \
      D               F
       \             /
        4           1
         \         /
              G
    */

    n = 7;

    graph[0][1] = 2;   // A -> B
    graph[0][2] = 5;   // A -> C

    graph[1][3] = 3;   // B -> D
    graph[1][4] = 6;   // B -> E

    graph[2][5] = 2;   // C -> F

    graph[3][6] = 4;   // D -> G
    graph[5][6] = 1;   // F -> G
    graph[4][6] = 2;   // E -> G

    for (i = 0; i < n; i++)
        visited[i] = 0;

    visited[0] = 1;
    currentPath[0] = 0;

    branchAndBound(0, 6, 1, 0);

    printf("\nBest Path: ");

    for (i = 0; i < n; i++)
    {
        if (bestPath[i] == 6)
        {
            printf("%c", 'A' + bestPath[i]);
            break;
        }

        printf("%c -> ", 'A' + bestPath[i]);
    }

    printf("\nBest Cost: %d\n", bestCost);

    return 0;
}