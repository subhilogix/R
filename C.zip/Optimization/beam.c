#include <stdio.h>
#define MAX_NODES 20
#define MAX_BEAM 10
int graph[MAX_NODES][MAX_NODES];
int value[MAX_NODES];
int beam[MAX_BEAM];
int beamSize;

void beamSearch(int start, int goal, int width)
{
    beam[0] = start;
    beamSize = 1;
    while (beamSize > 0)
    {
        printf("\nCurrent Beam: ");
        for (int i = 0; i < beamSize; i++)
        {
            printf("%c(%d) ",
                   'A' + beam[i],
                   value[beam[i]]);
        }
        // Check whether goal is in current beam
        for (int i = 0; i < beamSize; i++)
        {
            if (beam[i] == goal)
            {
                printf("\nGoal found: %c\n",
                       'A' + goal);
                return;
            }
        }

        int candidates[MAX_NODES];
        int candidateCount = 0;

        // Expand every node in current beam
        for (int i = 0; i < beamSize; i++)
        {
            int current = beam[i];
            for (int j = 0; j < MAX_NODES; j++)
            {
                if (graph[current][j] == 1)
                {
                    candidates[candidateCount++] = j;
                }
            }
        }
        if (candidateCount == 0)
        {
            printf("\nNo more candidates.\n");
            return;
        }
        // Select best 'width' candidates
        for (int i = 0; i < candidateCount - 1; i++)
        {
            for (int j = i + 1; j < candidateCount; j++)
            {
                if (value[candidates[j]] >
                    value[candidates[i]])
                {
                    int temp = candidates[i];
                    candidates[i] = candidates[j];
                    candidates[j] = temp;
                }
            }
        }
        beamSize = 0;
        for (int i = 0;i < candidateCount && i < width;i++)
        {
            beam[beamSize++] = candidates[i];
        }
    }
}

int main()
{
    // Values
    value[0] = 0;   // A
    value[1] = 6;   // B
    value[2] = 9;   // C
    value[3] = 5;   // D
    value[4] = 7;   // E
    value[5] = 4;   // F
    value[6] = 8;   // G
    value[7] = 10;  // H
    value[8] = 3;   // I
    value[9] = 6;   // J

    // A -> B, C, D
    graph[0][1] = 1;
    graph[0][2] = 1;
    graph[0][3] = 1;

    // B -> E, F
    graph[1][4] = 1;
    graph[1][5] = 1;

    // C -> G, H
    graph[2][6] = 1;
    graph[2][7] = 1;

    // D -> I, J
    graph[3][8] = 1;
    graph[3][9] = 1;

    // Beam width = 2
    beamSearch(0, 7, 4);

    return 0;
}