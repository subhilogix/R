#include<stdio.h>
#include<limits.h>
int graph[10][10];
int value[10];
int beam[10];
int beamsize;
void bs(int start,int goal,int width){
    beam[0]=start;
    beamsize=1;
    while(beamsize>0){
        printf("\nCURRENT BEAM :");
        for(int i=0;i<beamsize;i++){
            printf("%c(%d)",'A'+beam[i],value[beam[i]]);
        }
        for(int i=0;i<beamsize;i++){
            if(beam[i]==goal){
                printf("\nGOAL FOUND:%c\n",'A'+beam[i]);
                return;
            }
        }
        int children[10];
        int childcount=0;
        for(int i=0;i<beamsize;i++){
            int current=beam[i];
            for(int j=0;j<10;j++){
                if(graph[current][j]==1){
                    children[childcount++]=j;
                }
            }
        }
        if(childcount==0){
            printf("\nNo more successors\n");
            return;
        }
        for(int i=0;i<childcount-1;i++){
            for(int j=i+1;j<childcount;j++){
                if(value[children[j]]>value[children[i]]){
                    int temp=value[children[i]];
                    children[i]=children[j];
                    children[j]=temp;
                }
            }
        }
        beamsize=0;
        for(int i=0;i<width&& i<childcount;i++){
            beam[beamsize++]=children[i];
        }

    }

}
int main()
{
    // Values of nodes
    value[0] = 5;    // A
    value[1] = 8;    // B
    value[2] = 6;    // C
    value[3] = 7;    // D
    value[4] = 10;   // E
    value[5] = 9;    // F
    value[6] = 12;   // G
    value[7] = 11;   // H

    // Connections - directed graph

    graph[0][1] = 1;   // A -> B
    graph[0][2] = 1;   // A -> C

    graph[1][3] = 1;   // B -> D
    graph[1][4] = 1;   // B -> E

    graph[2][5] = 1;   // C -> F

    graph[4][6] = 1;   // E -> G
    graph[4][7] = 1;   // E -> H

    bs(0, 6, 2);

    return 0;
}

